/**
 * Amazon Connect Transcription Dashboard Service
 *
 * A third-party service that displays real-time call transcripts
 * in the Amazon Connect Agent Workspace.
 */
import { TranscriptionService } from './TranscriptionService';
import './styles.css';
declare let transcriptionService: TranscriptionService | null;
export { transcriptionService };
//# sourceMappingURL=index.d.ts.map