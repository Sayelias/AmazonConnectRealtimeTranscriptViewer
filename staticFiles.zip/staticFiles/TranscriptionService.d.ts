/**
 * TranscriptionService - Amazon Connect SDK Integration
 * Automatically detects contact ID when agent accepts a call.
 */
export interface TranscriptSegment {
    id: string;
    timestamp: string;
    participantRole: 'AGENT' | 'CUSTOMER' | 'SYSTEM';
    content: string;
    sentiment: 'POSITIVE' | 'NEGATIVE' | 'NEUTRAL';
}
export interface TranscriptResponse {
    success: boolean;
    contactId: string;
    callStatus: 'active' | 'ended' | 'unknown';
    segments: TranscriptSegment[];
    segmentCount: number;
    lastUpdated: string;
}
export type ServiceStatus = 'initializing' | 'connected' | 'disconnected' | 'error';
export type ContactStatus = 'waiting' | 'active' | 'acw' | 'ended';
export declare class TranscriptionService {
    private status;
    private contactId;
    private contactStatus;
    private segments;
    private pollTimer;
    private isInAgentWorkspace;
    private onStatusChange;
    private onContactChange;
    private onTranscriptUpdate;
    constructor();
    setCallbacks(cb: {
        onStatusChange?: (s: ServiceStatus) => void;
        onContactChange?: (id: string | null, s: ContactStatus) => void;
        onTranscriptUpdate?: (segs: TranscriptSegment[]) => void;
    }): void;
    initialize(): Promise<void>;
    private tryAmazonConnectApp;
    private tryLegacySDK;
    private checkUrlForContactId;
    private handleContactConnected;
    private handleContactAcw;
    private handleContactCleared;
    private startPolling;
    private stopPolling;
    private fetchTranscript;
    setContactId(cid: string): void;
    clearContact(): void;
    getState(): {
        status: ServiceStatus;
        contactId: string | null;
        contactStatus: ContactStatus;
        segments: TranscriptSegment[];
        isInAgentWorkspace: boolean;
    };
}
//# sourceMappingURL=TranscriptionService.d.ts.map