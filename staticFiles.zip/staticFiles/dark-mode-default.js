// Set dark mode as default - runs immediately and on DOMContentLoaded
(function() {
  function setDarkMode() {
    const currentTheme = localStorage.getItem('awsui-theme') || localStorage.getItem('theme');
    
    if (!currentTheme) {
      localStorage.setItem('awsui-theme', 'dark');
      localStorage.setItem('theme', 'dark');
      document.documentElement.classList.add('awsui-dark-mode');
      document.documentElement.setAttribute('data-awsui-theme', 'dark');
      if (document.body) {
        document.body.classList.add('awsui-dark-mode');
      }
    } else if (currentTheme === 'dark') {
      document.documentElement.classList.add('awsui-dark-mode');
      document.documentElement.setAttribute('data-awsui-theme', 'dark');
      if (document.body) {
        document.body.classList.add('awsui-dark-mode');
      }
    }
  }
  
  // Run immediately
  setDarkMode();
  
  // Run again when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setDarkMode);
  }
})();
