// Theme persistence - respects user's saved preference, defaults to dark for first visit
(function() {
  function applyTheme() {
    var saved = localStorage.getItem('awsui-theme') || localStorage.getItem('theme');
    var theme = saved || 'dark'; // default to dark only on first visit

    // Store the theme so it persists across reloads
    localStorage.setItem('awsui-theme', theme);
    localStorage.setItem('theme', theme);

    if (theme === 'dark') {
      document.documentElement.classList.add('awsui-dark-mode');
      document.documentElement.setAttribute('data-awsui-theme', 'dark');
      if (document.body) {
        document.body.classList.add('awsui-dark-mode');
      }
    } else {
      document.documentElement.classList.remove('awsui-dark-mode');
      document.documentElement.setAttribute('data-awsui-theme', 'light');
      if (document.body) {
        document.body.classList.remove('awsui-dark-mode');
      }
    }
  }

  // Run immediately (before bundle.js)
  applyTheme();

  // Run again when DOM is ready to catch body element
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', applyTheme);
  }
})();
