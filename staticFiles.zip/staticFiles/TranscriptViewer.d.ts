/**
 * TranscriptViewer - Cloudscape Design System UI with Sentiment Graph
 */
import React from 'react';
import '@cloudscape-design/global-styles/index.css';
import { TranscriptionService } from './TranscriptionService';
interface TranscriptViewerProps {
    service: TranscriptionService;
}
export declare const TranscriptViewer: React.FC<TranscriptViewerProps>;
export {};
//# sourceMappingURL=TranscriptViewer.d.ts.map